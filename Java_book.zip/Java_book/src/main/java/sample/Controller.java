package sample;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ToggleButton;
import javafx.scene.layout.Pane;

import java.net.URL;
import java.util.ResourceBundle;

public class Controller implements Initializable {

    @FXML
    private Pane drawingPane;

    @FXML
    private ToggleButton titleButton;
    @FXML
    private ToggleButton borderButton;
    @FXML
    private ToggleButton bookmarkButton;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // Ждём отрисовки панели, потом рисуем книгу
        drawingPane.widthProperty().addListener((_, _, _) -> rebuildBook());
        drawingPane.heightProperty().addListener((_, _, _) -> rebuildBook());
    }

    // Обработчик любой кнопки-переключателя
    @FXML
    public void onDecoratorToggle() {
        rebuildBook();
    }

    // Сброс всех кнопок
    @FXML
    public void reset() {
        titleButton.setSelected(false);
        borderButton.setSelected(false);
        bookmarkButton.setSelected(false);
        rebuildBook();
    }

    // Пересборка книги с учётом состояния кнопок
    private void rebuildBook() {
        // Начинаем с базовой книги
        BookComponent book = new SimpleBook();

        // Добавляем декораторы в зависимости от состояния кнопок
        if (titleButton != null && titleButton.isSelected()) {
            book = new TitleDecorator(book);
        }
        if (borderButton != null && borderButton.isSelected()) {
            book = new GoldBorderDecorator(book);
        }
        if (bookmarkButton != null && bookmarkButton.isSelected()) {
            book = new BookmarkDecorator(book);
        }

        // Перерисовываем
        drawingPane.getChildren().clear();
        book.operation(drawingPane);
    }
}
