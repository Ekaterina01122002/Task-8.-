package sample;

import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

// Интерфейс компонента книги
interface BookComponent {
    void operation(Pane pane); // Отрисовка

    String decorate(); // Описание (требуется по пункту 2)

    float cost(); // Стоимость (требуется по пункту 2)
}

// Базовая книга без украшений
class SimpleBook implements BookComponent {

    private static final double BOOK_WIDTH = 200;
    private static final double BOOK_HEIGHT = 280;

    @Override
    public void operation(Pane pane) {
        double centerX = pane.getWidth() / 2 - BOOK_WIDTH / 2;
        double centerY = pane.getHeight() / 2 - BOOK_HEIGHT / 2;

        // Обложка книги
        Rectangle cover = new Rectangle(centerX, centerY, BOOK_WIDTH, BOOK_HEIGHT);
        cover.setFill(Color.SADDLEBROWN);
        cover.setArcWidth(10);
        cover.setArcHeight(10);

        // Корешок
        Rectangle spine = new Rectangle(centerX, centerY, 20, BOOK_HEIGHT);
        spine.setFill(Color.SIENNA);
        spine.setArcWidth(5);
        spine.setArcHeight(5);

        pane.getChildren().addAll(cover, spine);
    }

    @Override
    public String decorate() {
        return "Обычная книга";
    }

    @Override
    public float cost() {
        return 100.0f;
    }
}

// Абстрактный декоратор - базовый класс для всех украшений
abstract class BookDecorator implements BookComponent {
    protected BookComponent bookComponent;

    public BookDecorator(BookComponent bookComponent) {
        this.bookComponent = bookComponent;
    }

    @Override
    public void operation(Pane pane) {
        bookComponent.operation(pane);
    }

    @Override
    public String decorate() {
        return bookComponent.decorate();
    }

    @Override
    public float cost() {
        return bookComponent.cost();
    }
}

// Декоратор: добавляет название на обложку
class TitleDecorator extends BookDecorator {

    public TitleDecorator(BookComponent bookComponent) {
        super(bookComponent);
    }

    @Override
    public void operation(Pane pane) {
        super.operation(pane);

        Text title = new Text("ДЕКОРАТОР");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        title.setFill(Color.GOLD);

        // Центрируем текст на обложке
        double centerX = pane.getWidth() / 2 - title.getLayoutBounds().getWidth() / 2;
        double centerY = pane.getHeight() / 2 - 60;
        title.setX(centerX);
        title.setY(centerY);

        pane.getChildren().add(title);
    }

    @Override
    public String decorate() {
        return super.decorate() + " + название";
    }

    @Override
    public float cost() {
        return super.cost() + 50.0f;
    }
}

// Декоратор: добавляет золотую рамку
class GoldBorderDecorator extends BookDecorator {

    private static final double BOOK_WIDTH = 200;
    private static final double BOOK_HEIGHT = 280;

    public GoldBorderDecorator(BookComponent bookComponent) {
        super(bookComponent);
    }

    @Override
    public void operation(Pane pane) {
        super.operation(pane);

        double centerX = pane.getWidth() / 2 - BOOK_WIDTH / 2;
        double centerY = pane.getHeight() / 2 - BOOK_HEIGHT / 2;

        // Золотая рамка с отступом от края
        Rectangle border = new Rectangle(
                centerX + 15, centerY + 15,
                BOOK_WIDTH - 30, BOOK_HEIGHT - 30);
        border.setFill(Color.TRANSPARENT);
        border.setStroke(Color.GOLD);
        border.setStrokeWidth(3);
        border.setArcWidth(8);
        border.setArcHeight(8);

        pane.getChildren().add(border);
    }

    @Override
    public String decorate() {
        return super.decorate() + " + окантовка";
    }

    @Override
    public float cost() {
        return super.cost() + 200.0f;
    }
}

// Декоратор: добавляет закладку-ленточку
class BookmarkDecorator extends BookDecorator {

    private static final double BOOK_WIDTH = 200;
    private static final double BOOK_HEIGHT = 280;

    public BookmarkDecorator(BookComponent bookComponent) {
        super(bookComponent);
    }

    @Override
    public void operation(Pane pane) {
        super.operation(pane);

        double centerX = pane.getWidth() / 2 - BOOK_WIDTH / 2;
        double centerY = pane.getHeight() / 2 - BOOK_HEIGHT / 2;

        // Красная ленточка-закладка, выступает снизу
        double ribbonX = centerX + BOOK_WIDTH - 50;
        Line ribbon = new Line(
                ribbonX, centerY,
                ribbonX, centerY + BOOK_HEIGHT + 30);
        ribbon.setStroke(Color.CRIMSON);
        ribbon.setStrokeWidth(8);

        pane.getChildren().add(ribbon);
    }

    @Override
    public String decorate() {
        return super.decorate() + " + закладка";
    }

    @Override
    public float cost() {
        return super.cost() + 30.0f;
    }
}
