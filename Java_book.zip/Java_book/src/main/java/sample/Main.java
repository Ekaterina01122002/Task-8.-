package sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Objects;

public class Main {
    static void main(String[] args) {
        // Явный запуск вложенного класса приложения
        Application.launch(App.class, args);
    }

    // Вложенный класс должен быть public static для JavaFX
    public static class App extends Application {
        @Override
        public void start(Stage primaryStage) throws IOException {
            URL fxmlUrl = Objects.requireNonNull(
                    getClass().getResource("sample.fxml"),
                    "Не найден файл sample.fxml в ресурсах");
            Parent root = FXMLLoader.load(fxmlUrl);
            primaryStage.setTitle("Паттерн Декоратор - Книга");
            primaryStage.setScene(new Scene(root, 600, 500));
            primaryStage.setMinWidth(550);
            primaryStage.setMinHeight(400);
            primaryStage.show();
        }
    }
}
